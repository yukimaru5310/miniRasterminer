# ECGFiveDays

Data are from a 67 year old male. The two classes correspond to two dates that the ECG was recorded, which are five days apart: 12/11/1990 and 17/11/1990.

Train size: 23

Test size: 861

Missing value: No

Number of classses: 2

Time series length: 136

Data donated by Yanping Chen and Eamonn Keogh (see [1]).

[1] http://www.timeseriesclassification.com/description.php?Dataset=ECGFiveDays